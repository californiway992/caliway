# 1Channel Plugin for KODI/XMBC4XBOX

# Python internal imports
import base64
import os
import re
import sys
import urllib
import urllib2

try:
    from urlparse import parse_qs
except ImportError:
    # python 2.4 compatibility
    from cgi import parse_qs
    urlparse.parse_qs = parse_qs

# External library imports
from BeautifulSoup import BeautifulSoup, SoupStrainer

# KODI/XBMC4XBOX specific imports
import xbmc
import xbmcplugin
import xbmcgui
import xbmcaddon

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
args = urlparse.parse_qs(sys.argv[2][1:])


# COMMON PLUGIN FUNCTIONS

# sub folder url link
def build_url(query):
    return base_url + '?' + urllib.urlencode(query)


# url web request
def url_request(link, data=None):
    print '>>>>>1Channel Plugin :: url_request :: url = ' + link
    # chrome web browser
    user_agent = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) ' \
                 'Chrome/49.0.2623.112 Safari/537.36'
    try:
        req = urllib2.Request(link)
        req.add_header('User-Agent', user_agent)
        if data:
            req.add_data(data)
        response = urllib2.urlopen(req, timeout=15)
        text = response.read()
        response.close()
        return text
    except urllib2.URLError as e:
        if hasattr(e, 'reason'):
            print '>>>>>1Channel Plugin : URLError while trying to reach a server: ', e.reason
        elif hasattr(e, 'code'):
            print '>>>>>1Channel Plugin : URLError server could not fulfill request: ', e.code

        xbmc.executebuiltin('Notification(1Channel Plugin, Network Error, 5000, DefaultIconError.png')
        return None


# get playable url stream
def url_resolver(url, domain):
    # set max video quality from settings
    video_quality_setting = addon.getSetting('maxvideoquality')
    print '>>>>>1Channel Plugin : Max Video Quality = ' + video_quality_setting
    max_video_quality = int(video_quality_setting.rstrip('p'))

    # determine which domain the url is from
    if domain == 'thevideo.me':
        pattern = '.+?thevideo\.me/([0-9a-zA-Z]+)'
        r = re.search(pattern, url)
        host_url = 'http://' + domain + '/embed-' + r.group(1) + '.html'
        data = url_request(host_url)
        if data:
            r = re.findall("label\s*:\s*'(.+?)p'\s*,\s*file\s*:\s*'(.+?)'", data)
            if not r:
                xbmc.executebuiltin('Notification(1Channel, File not found or deleted, 5000, DefaultIconError.png)')
            else:
                for quality, stream_url in r:
                    if int(quality) <= max_video_quality:
                        best_stream_url = stream_url
                return best_stream_url
        else:
            pass

    elif domain == 'promptfile.com':
        data = url_request(url)
        if data:
            r = re.findall('type\s*=\s*"hidden".+?name\s*=\s*"(.+?)"\s*value\s*=\s*"(.+?)"', data)
            for name, value in r:
                post_data = name + '=bb' + value
            data = url_request(url, data=post_data)
            if data:
                stream = re.search('clip\s*:\s*\{\s*url\s*:\s*[\"\'](.+?)[\"\']', data)
                if stream:
                    stream_url = stream.group(1)
                    return stream_url
                else:
                    xbmc.executebuiltin('Notification(1Channel, File not found or deleted, 5000, DefaultIconError.png)')
            else:
                pass
        else:
            pass

    else:
        xbmc.executebuiltin('Notification(1Channel, That host is not supported, 5000, DefaultIconError.png)')
        return None


# COMMON PLUGIN VARIABLES
addon = xbmcaddon.Addon('plugin.video.1channel')
website_base = 'http://www.primewire.ag'
best_stream_domains = ('thevideo.me', 'promptfile.com')
mode = args.get('mode', None)

if mode is None:
    name = 'Movies'
    url = build_url({'mode': 'movies', 'foldername': name})
    li = xbmcgui.ListItem(name, iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    name = 'TV'
    url = build_url({'mode': 'tv', 'foldername': name})
    li = xbmcgui.ListItem(name, iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(addon_handle)

elif mode[0] == 'movies':
    name = 'Search for Movie'
    url = build_url({'mode': 'search', 'foldername': name, 'searchtype': 'check', 'videotype': 'movie'})
    li = xbmcgui.ListItem(name, iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    name = '[COLOR yellow]>>>>>>>>>>Featured Movies<<<<<<<<<<[/COLOR]'
    li = xbmcgui.ListItem(name, iconImage='none')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url='', listitem=li, isFolder=False)

    featured_movies_url = website_base + '/?sort=featured'
    data = url_request(featured_movies_url)
    if data:
        strainer = SoupStrainer(attrs={'class': 'index_container'})
        container = BeautifulSoup(data, parseOnlyThese=strainer)
        for movie in container.findAll(attrs={'class': 'index_item index_item_ie'}):
            name = movie.a['title'].replace('Watch ', '').encode('ascii', 'ignore')
            video_url = website_base + movie.a['href']
            thumb = 'http:' + movie.a.img['src']
            url = build_url({'mode': 'videoinspect', 'foldername': name, 'url': video_url, 'videotitle': name})
            li = xbmcgui.ListItem(name, iconImage='DefaultFolder.png')
            li.setThumbnailImage(thumb)
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
    else:
        pass

    xbmcplugin.endOfDirectory(addon_handle)

elif mode[0] == 'tv':
    name = 'Search for TV Show'
    url = build_url({'mode': 'search', 'foldername': name, 'searchtype': 'check', 'videotype': 'tv'})
    li = xbmcgui.ListItem(name, iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    name = '[COLOR yellow]>>>>>>>>>>Featured TV Shows<<<<<<<<<<[/COLOR]'
    li = xbmcgui.ListItem(name, iconImage='none')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url='', listitem=li, isFolder=False)

    featured_tv_url = website_base + '/?tv=&sort=featured'
    data = url_request(featured_tv_url)
    if data:
        strainer = SoupStrainer(attrs={'class': 'index_container'})
        container = BeautifulSoup(data, parseOnlyThese=strainer)
        for tv_show in container.findAll(attrs={'class': 'index_item index_item_ie'}):
            name = tv_show.a['title'].replace('Watch ', '').encode('ascii', 'ignore')
            video_url = website_base + tv_show.a['href']
            thumb = 'http:' + tv_show.a.img['src']
            url = build_url({'mode': 'videoinspect', 'foldername': name, 'url': video_url, 'videotitle': name})
            li = xbmcgui.ListItem(name, iconImage='DefaultFolder.png')
            li.setThumbnailImage(thumb)
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
    else:
        pass

    xbmcplugin.endOfDirectory(addon_handle)

elif mode[0] == 'search':
    video_type = args['videotype'][0]
    search_type = args['searchtype'][0]
    addon_path = addon.getAddonInfo('path')
    search_data = os.path.join(addon_path, 'resources', 'data', '{0}searchdata.txt'.format(video_type))
    if search_type == 'check':
        f = open(search_data, 'r')
        search_history = f.readlines()
        f.close()
        if len(search_history) > 0:
            name = 'Start New Search'
            url = build_url({'mode': 'search', 'foldername': name, 'searchtype': 'keyboard', 'videotype': video_type})
            li = xbmcgui.ListItem(name, iconImage='DefaultFolder.png')
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

            for search in search_history:
                name = search.strip('\n')
                url = build_url({'mode': 'search', 'foldername': name, 'searchtype': 'data', 'videotype': video_type})
                li = xbmcgui.ListItem(name, iconImage='DefaultFolder.png')
                xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

            name = 'Clear Search Data'
            url = build_url({'mode': 'search', 'foldername': name, 'searchtype': 'clear', 'videotype': video_type})
            li = xbmcgui.ListItem(name, iconImage='none')
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=False)
        else:
            search = ''
            keyboard = xbmc.Keyboard(search, '1Channel Search')
            keyboard.doModal()
            if keyboard.isConfirmed():
                if len(keyboard.getText()) > 0:
                    f = open(search_data, 'a')
                    f.write(keyboard.getText() + '\n')
                    f.close()
                else:
                    pass
                search = urllib.quote_plus(keyboard.getText())
                url = website_base + '/index.php?search_keywords=' + search
                data = url_request(url)
                if data:
                    strainer = SoupStrainer(attrs={'class': 'index_container'})
                    container = BeautifulSoup(data, parseOnlyThese=strainer)
                    for item in container.findAll(attrs={'class': 'index_item index_item_ie'}):
                        name = item.a['title'].replace('Watch ', '').encode('ascii', 'ignore')
                        video_url = website_base + item.a['href']
                        thumb = 'http:' + item.a.img['src']
                        url = build_url({'mode': 'videoinspect', 'foldername': name, 'url': video_url,
                                         'videotitle': name})
                        li = xbmcgui.ListItem(name, iconImage='DefaultFolder.png')
                        li.setThumbnailImage(thumb)
                        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
                else:
                    pass
            else:
                pass
    elif search_type == 'keyboard':
        search = ''
        keyboard = xbmc.Keyboard(search, '1Channel Search')
        keyboard.doModal()
        if keyboard.isConfirmed():
            if len(keyboard.getText()) > 0:
                f = open(search_data, 'a')
                f.write(keyboard.getText() + '\n')
                f.close()
            else:
                pass
            search = urllib.quote_plus(keyboard.getText())
            url = website_base + '/index.php?search_keywords=' + search
            data = url_request(url)
            if data:
                strainer = SoupStrainer(attrs={'class': 'index_container'})
                container = BeautifulSoup(data, parseOnlyThese=strainer)
                for item in container.findAll(attrs={'class': 'index_item index_item_ie'}):
                    name = item.a['title'].replace('Watch ', '').encode('ascii', 'ignore')
                    video_url = website_base + item.a['href']
                    thumb = 'http:' + item.a.img['src']
                    url = build_url({'mode': 'videoinspect', 'foldername': name, 'url': video_url,
                                     'videotitle': name})
                    li = xbmcgui.ListItem(name, iconImage='DefaultFolder.png')
                    li.setThumbnailImage(thumb)
                    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
            else:
                pass
        else:
            pass
    elif search_type == 'data':
        search = urllib.quote_plus(args['foldername'][0])
        url = website_base + '/index.php?search_keywords=' + search
        data = url_request(url)
        if data:
            strainer = SoupStrainer(attrs={'class': 'index_container'})
            container = BeautifulSoup(data, parseOnlyThese=strainer)
            for item in container.findAll(attrs={'class': 'index_item index_item_ie'}):
                name = item.a['title'].replace('Watch ', '').encode('ascii', 'ignore')
                video_url = website_base + item.a['href']
                thumb = 'http:' + item.a.img['src']
                url = build_url({'mode': 'videoinspect', 'foldername': name, 'url': video_url,
                                 'videotitle': name})
                li = xbmcgui.ListItem(name, iconImage='DefaultFolder.png')
                li.setThumbnailImage(thumb)
                xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
        else:
            pass
    elif search_type == 'clear':
        open(search_data, 'w').close()
        if video_type == 'movie':
            url = build_url({'mode': 'movies', 'foldername': 'Movies'})
        else:
            url = build_url({'mode': 'tv', 'foldername': 'TV'})
        xbmc.executebuiltin('Container.Update({0}, replace)'.format(url))
    else:
        pass

    xbmcplugin.endOfDirectory(addon_handle)

elif mode[0] == 'videoinspect':
    video_title = args['videotitle'][0]
    video_page = args['url'][0]
    data = url_request(video_page)
    if data:
        strainer = SoupStrainer(attrs={'class': 'tv_container'})
        container = BeautifulSoup(data, parseOnlyThese=strainer)
        seasons = container.findAll(attrs={'class': 'show_season'})
        if len(seasons) > 0:
            for season in seasons:
                season_number = season['data-id']
                name = 'Season ' + season_number
                li = xbmcgui.ListItem('[COLOR yellow]' + name + '[/COLOR]')
                li.setThumbnailImage('none')
                xbmcplugin.addDirectoryItem(handle=addon_handle, url='', listitem=li, isFolder=False)

                for episode in season.findAll('div'):
                    episode_name = episode.a.contents[0].strip() + episode.a.span.contents[0]
                    episode_name_clean = episode_name.encode('ascii', 'ignore')
                    episode_url = website_base + episode.a['href']
                    url = build_url({'mode': 'videoinspect', 'foldername': episode_name_clean, 'url': episode_url,
                                     'videotitle': video_title + ' - ' + name + ' - ' + episode_name_clean})
                    li = xbmcgui.ListItem(episode_name_clean, iconImage='DefaultFolder.png')
                    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
        else:
            soup = BeautifulSoup(data)
            for video in soup.findAll(href=re.compile('^/goto.php')):
                try:
                    name = video['title'].replace('Watch ', '')
                    video_url = video['href']
                    encoded_domain = re.compile('domain=(.+?)&logged').findall(video_url)
                    domain = base64.b64decode(encoded_domain[0])
                    if re.match('^Version', name):
                        if domain in best_stream_domains:
                            full_name = '[COLOR yellow]' + name + ' [' + domain + ']' + '[/COLOR]'
                        else:
                            full_name = name + ' [' + domain + ']'
                        url = build_url({'mode': 'videolink', 'foldername': full_name, 'url': video_url,
                                         'videotitle': video_title, 'videodomain': domain})
                        li = xbmcgui.ListItem(full_name, iconImage='DefaultFolder.png')
                        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
                    else:
                        pass
                except:
                    pass
    else:
        pass

    xbmcplugin.endOfDirectory(addon_handle)

elif mode[0] == 'videolink':
    name = args['videotitle'][0]
    video_url = args['url'][0]
    domain = args['videodomain'][0]
    encoded_url = re.search('url=(.+?)&domain', video_url)
    decoded_url = base64.b64decode(encoded_url.group(1))
    url = url_resolver(decoded_url, domain)
    if url:
        li = xbmcgui.ListItem(name, iconImage='DefaultVideo.png')
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=False)
    else:
        pass

    xbmcplugin.endOfDirectory(addon_handle)