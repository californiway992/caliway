# Test URL Request File

# Imports
import urllib2, re, base64
from BeautifulSoup import BeautifulSoup, SoupStrainer

# url web request
def get_url(url):
    print '>>>>>TestFile :: get_url :: url = ' + url
    # chrome web browser
    user_agent = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) ' \
                 'Chrome/49.0.2623.112 Safari/537.36'
    try:
        req = urllib2.Request(url)
        req.add_header('User-Agent', user_agent)
        response = urllib2.urlopen(req, timeout=15)
        text = response.read()
        response.close()
        return text
    except urllib2.URLError as e:
        if hasattr(e, 'reason'):
            print '>>>>>1Channel Plugin : URLError while trying to reach a server: ', e.reason
        elif hasattr(e, 'code'):
            print '>>>>>1Channel Plugin : URLError server could not fulfill request: ', e.code

        # xbmc.executebuiltin('Notification(1Channel Plugin, Network Error, 5000, DefaultIconError.png')
        return False

website_base = 'http://www.primewire.ag'
beststreamdomains = ('briskfile.com', 'promptfile.com', 'thevideo.me')

videopage = website_base + '/tv-2745400-Silicon-Valley/season-2-episode-10'
data = get_url(videopage)
if data:
    # strainer = SoupStrainer(attrs={'class': 'index_container'})
    # container = BeautifulSoup(data, parseOnlyThese=strainer)
    soup = BeautifulSoup(data)
    for video in soup.findAll(href=re.compile('^/goto.php')):
        try:
            name = video['title']
            videourl = video['href']
            encodeddomain = re.compile('domain=(.+?)&logged').findall(videourl)
            domain = base64.b64decode(encodeddomain[0])
            if domain in beststreamdomains:
                print ''
                print name.replace('Watch ', '') + ' [' + domain + '] yellow'
            else:
                print ''
                print name.replace('Watch ', '') + ' [' + domain + ']'
        except:
            pass
else:
    pass