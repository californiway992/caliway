# Test URL Request File

# Imports
import urllib2, re, base64
from BeautifulSoup import BeautifulSoup, SoupStrainer

# url web request
def url_request(link, data=None):
    print '>>>>>1Channel Plugin :: url_request :: url = ' + link
    # chrome web browser
    user_agent = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) ' \
                 'Chrome/49.0.2623.112 Safari/537.36'
    try:
        req = urllib2.Request(link)
        req.add_header('User-Agent', user_agent)
        if data:
            req.add_data(data)
        response = urllib2.urlopen(req, timeout=15)
        text = response.read()
        response.close()
        return text
    except urllib2.URLError as e:
        if hasattr(e, 'reason'):
            print '>>>>>1Channel Plugin : URLError while trying to reach a server: ', e.reason
        elif hasattr(e, 'code'):
            print '>>>>>1Channel Plugin : URLError server could not fulfill request: ', e.code

        #xbmc.executebuiltin('Notification(1Channel Plugin, Network Error, 5000, DefaultIconError.png')
        return None

videopage = 'http://www.promptfile.com/l/DD21F3D416-FEC5EB1CC4'
data = url_request(videopage)
if data:
    r = re.findall('type\s*=\s*"hidden".+?name\s*=\s*"(.+?)"\s*value\s*=\s*"(.+?)"', data)
    for name, value in r:
        post_data = name + '=bb' + value
        print post_data
    data = url_request(videopage, data=post_data)
    if data:
        stream = re.search('clip\s*:\s*\{\s*url\s*:\s*[\"\'](.+?)[\"\']', data)
        if stream:
            stream_url = stream.group(1)
            print stream_url
        else:
            #xbmc.executebuiltin('Notification(1Channel, File not found or deleted, 5000, DefaultIconError.png)')
            pass
    else:
        pass
else:
    pass